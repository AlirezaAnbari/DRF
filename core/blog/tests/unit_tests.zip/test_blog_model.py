from django.test import TestCase
from datetime import datetime
from django.contrib.auth import get_user_model
from accounts.models import User, Profile
from ..models import Post, Category


class TestPostModel(TestCase):
    
    def setUp(self):
        self.category_obj = Category.objects.create(name='test name')
        self.user = User.objects.create(email='test@test.com', password='123')
        self.profile = Profile.objects.create(
                    user=self.user,
                    first_name= 'test name',
                    last_name= 'test last name',
                    description= 'test description',
        )
    
    def test_create_post_with_valid_data(self):
        post = Post.objects.create(
            author= self.profile,
            title= 'test',
            content= 'desc',
            status= True,
            category= self.category_obj,
            published_date= datetime.now(),
        )
        self.assertTrue(Post.objects.filter(pk=post.id).exists(), True)
        self.assertEquals(post.title, 'test')