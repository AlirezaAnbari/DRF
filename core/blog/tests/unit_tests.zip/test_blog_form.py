from django.test import SimpleTestCase
from ..forms import PostForm   

# Create your tests here.